var components=[{name:"mouse",use:"pointing",color:"white",brand:"razor",},
                {name:"keyboard",use:"typing",color:"black",brand:"logitech"},
                {name:"monitor",use:"display",color:"black",brand:"acer"},
                {name:"hdd",use:"storage",color:"grey",brand:"segate"},
                {name:"headphones",use:"hear",color:"red",brand:"cosmicbyte"}]
for(let i=0;i<4;i++)
{
    console.log(components[i].name,components[i].use)
}


components.forEach(i => {
    console.log(i.name,i.use)
});
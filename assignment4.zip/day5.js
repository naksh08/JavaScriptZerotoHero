// for manipulating text of any Element
// document.getElementById("one").innerText="fantastic!"

// for manipulating document along with tags
// document.getElementById("one").innerHTML="<h1>ninna arri</h1>"

// event handling
function letsDo()
{
    console.log("😊😊😊")
}
//css manipluation
function letsDoit()
{
    document.getElementById("one").style.backgroundColor="grey"
}
//playing 
var colors=["indigo","blue","green","yellow","orange","red"]
var i=0
function ibgyor()
{
    document.getElementById("one").style.color="white"
    document.getElementById("one").style.backgroundColor=colors[i]
    i++
    
    if(i>=6)
    i=0
}

//manipulating attributes of an element



//taking input 
function Read()
{
    var data=document.getElementById("imp").value
    console.log(data)
}
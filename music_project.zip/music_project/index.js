var songs=[
    {
        id:1,
        imageSrc="./music_project/images/328_4.jpg",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Awaara Bhanware"
    },
    {
        id:2,
        imageSrc="./music_project/images/963-9634680_imagine-dragons-bad-liar.png",
        audioSrc:"./music_project/audios/Imagine_Dragons_-_Bad_Liar_talkglitz.tv.mp3",
        title:"Bad Liar"
    },
    {
        id:3,
        imageSrc="./images/download.jpg",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Unstopable"
    },
    {
        id:4,
        imageSrc="../images/download.jfif",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Beleiver"
    },
    {
        id:5,
        imageSrc="./images/Vardaan-Song-Carry-Minati-Status-Video-.jpg",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Vardaan"
    },
    {
        id:6,
        imageSrc="./images/Befikra Lyrics.JPG",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Befikra"
    },
    {
        id:7,
        imageSrc="./images/ab67616d0000b273ad40f4e70b2f2a2a6052d49d.jfif",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:">Ratta Maar"
    },
    {
        id:8,
        imageSrc="./images/ab67616d0000b273f1b90f92c449f315c6fee63f.jfif",
        audioSrc:"./music_project/audios/Awaara Bhanware Awaara Bhanware Dhrriti Saharan 128 Kbps.mp3",
        title:"Thanks a Lot"
    },
]

function playAudio(songid)
{
    var song=songs.find(function(song,index)
    {
        console.log(songid)
        return song.id===songid
    });
    document.getElementById("thumbnail").src=song.imageSrc;
    document.getElementById("audio_player").src=song.audioSrc;
    document.getElementById("audio_player_title").innerText=song.title;
    
}
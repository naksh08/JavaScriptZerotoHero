// 1.Program to print table of 5 ->
var num=5
for(let i=1;i<=10;i++)
{   
    console.log("5 x ",i,"= ",5*i)
}
// 2.Five variables holding marks of 5 subjects, calculate the percentage ->

var sub1=78
var sub2=38
var sub3=38
var sub4=84
var sub5=87
var per=(sub1+sub2+sub3+sub4+sub5)/5
console.log("Your Percentage is:",per,"%")
if(per>=75)
console.log("A")
else if(per<75 && per>=60)
console.log("B")
else if(per<60 && per>=40)
console.log("C")
else
console.log("Fail")
